<?php
$articulos = [ 'art01'   => ['descripcion' => "Móvil Samsung S24", 'precio' => 850],
               'art02'   => ['descripcion' => "Televisión Phillips OLED 50", 'precio' => 2500],
               'art03'   => ['descripcion' => "Reloj Smartwatch Huawei P2", 'precio' => 350],
               'art04'   => ['descripcion' => "Portátil HP i7 16 GB RAM 1TB SSD NVme", 'precio' => 1200],
               'art05'   => ['descripcion' => "Reproductor MP4 Energy Systems", 'precio' => 40],
               'art06'   => ['descripcion' => "Tablet Samsung S9", 'precio' => 900],
               'art07'   => ['descripcion' => "Proyector BENQ 2500 lm", 'precio' => 750],
               'art08'   => ['descripcion' => "Ordenador All-In-One i7 16 GB RAM 1TB SSD NVme", 'precio' => 800],
];
?>
